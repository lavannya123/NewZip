<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
		<?php
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$sid=$_GET['sid_id'];
					//$cid=$_GET['cid'];
					$total=0;
					$i=1;
					$sql2="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.class_id = class_tbl.id WHERE fees_tbl.sid='$sid' ";
					$result1=mysqli_query($con,$sql2);
					$rl=mysqli_fetch_row($result1);
					?>
			<div class="card-header">
				<h4><?php echo  $rl[12].' '.$rl[11].' '.$rl[13]; ?></h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter ">
					<thead>
						<tr>
							<th class="text-center ">ID</th>
							<!--<th class="hidden-xs"> Admission ID</th>-->
							<th class="text-center">Class_Name</th>
							<th class="hidden-xs text-center"> Paid Amount</th>
							<th class="hidden-xs w-20 text-center"> Date</th>
						
						</tr>
					</thead>
					<tbody>
					<?php
					$sql="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.class_id = class_tbl.id WHERE fees_tbl.sid='$sid' ";
									
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_row($result))
					{
							$total=$total+$row[3];
							?>
						<tr>
							
							
							<td class="hidden-xs text-center"><?php echo $i;?></td>
							<td class="hidden-xs text-center"><?php echo $row[2];?></td>
							<td class="hidden-xs text-center"><?php echo $total;?></td>
							<td class="hidden-xs text-center"><?php echo $row[6];?></td>
							
							
						</tr>
					<?php
					$i++;
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>