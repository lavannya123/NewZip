<!DOCTYPE html>
<html class="app-ui">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
        <title>School Management</title>
        <meta name="description" content="AppUI - Admin Dashboard Template & UI Framework" />
        <meta name="author" content="rustheme" />
        <meta name="robots" content="noindex, nofollow" />
        <link rel="apple-touch-icon" href="assets/img/favicons/apple-touch-icon.png" />
        <link rel="icon" href="assets/img/favicons/favicon.ico" />
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,900%7CRoboto+Slab:300,400%7CRoboto+Mono:400" />
        <link rel="stylesheet" href="assets/js/plugins/slick/slick.min.css" />
        <link rel="stylesheet" href="assets/js/plugins/slick/slick-theme.min.css" />
        <link rel="stylesheet" id="css-font-awesome" href="assets/css/font-awesome.css" />
        <link rel="stylesheet" id="css-ionicons" href="assets/css/ionicons.css" />
        <link rel="stylesheet" id="css-bootstrap" href="assets/css/bootstrap.css" />
        <link rel="stylesheet" id="css-app" href="assets/css/app.css" />
        <link rel="stylesheet" id="css-app-custom" href="assets/css/app-custom.css" />
		<link rel="stylesheet" href="assets/js/plugins/datatables/jquery.dataTables.min.css" />

    </head>

    <body class="app-ui layout-has-drawer layout-has-fixed-header">
        <div class="app-layout-canvas">
            <div class="app-layout-container">
                <aside class="app-layout-drawer">
                    <div class="app-layout-drawer-scroll">
                        <div id="logo" class="drawer-header">
                            <a href="index.php"><img class="img-responsive" src="assets/img/logo/vertex-logo.png" title="AppUI" alt="AppUI" /></a>
                        </div>
                        <nav class="drawer-main">
                            <ul class="nav nav-drawer">
                                <li class="nav-item active">
                                    <a href="index.php"><i class="ion-ios-speedometer-outline"></i> Dashboard</a>
                                </li>

                                <li class="nav-item nav-drawer-header"></li>
                                <li class="nav-item nav-item-has-subnav">
                                    <a href="add_class.php"><i class="ion-ios-calculator-outline"></i>Class</a>
                                    <!--<ul class="nav nav-subnav">
                                        <li>
                                            <a href="add_class.php">Add Class</a>
                                        </li>
                                        <li>
                                            <a href="class_list.php">View Class</a>
                                        </li>
                                    </ul>-->
                                </li>
                                <li class="nav-item nav-item-has-subnav">
                                    <a href="add_division.php"><i class="ion-ios-calculator-outline"></i>Divisions</a>
                                   
                                </li>
                                <li class="nav-item nav-item-has-subnav">
                                    <a href="javascript:void(0)"><i class="ion-ios-calculator-outline"></i>Registration </a>
                                    <ul class="nav nav-subnav">
                                        <li>
                                            <a href="add_admission.php">Add Registration Info</a>
                                        </li>
                                        <li>
                                            <a href="admission_list.php">View Registration Info</a>
                                        </li>
                                    </ul>
                                </li>
								<li class="nav-item nav-item-has-subnav">
                                    <a href="add_joining.php"><i class="ion-ios-calculator-outline"></i>Admission</a>
                                    
                                </li>
								
								<li class="nav-item nav-item-has-subnav">
                                    <a href="add_fees.php"><i class="ion-ios-calculator-outline"></i>Fees</a>
                                    
                                </li>
								<li class="nav-item">
                                    <a href="studentdetails.php"><i class="ion-ios-calculator-outline"></i>Fees Reports</a>

                                </li>
								<!--<li class="nav-item">
                                    <a href="fees_installments.php"><i class="ion-ios-calculator-outline"></i>Class</a>

                                </li>-->
								
                            </ul>
                        </nav>
                    </div>
                </aside>
				
				<header class="app-layout-header">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="header-navbar-collapse">
                                <ul class="nav navbar-nav navbar-right navbar-toolbar hidden-sm hidden-xs">
                                    <li class="dropdown dropdown-profile">
                                        <a href="javascript:void(0)" data-toggle="dropdown">
                                            <span class="m-r-sm">John Doe </span>
                                            <img class="img-avatar img-avatar-48" src="assets/img/avatars/avatar3.jpg" alt="User profile pic" />
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </header>