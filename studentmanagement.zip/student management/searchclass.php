<?php
$id=$_GET["id"];
//echo $id;
$con=mysqli_connect('localhost', 'root', '', 'school_management');

$sql="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where class_tbl.id='$id' GROUP BY fees_tbl.sid";


$sql2="SELECT sum(paid_fees) FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where class_tbl.id='$id' GROUP BY fees_tbl.sid";
$rd=mysqli_query($con,$sql2);
$result=mysqli_query($con,$sql);



while($row=mysqli_fetch_row($result))
{
    $rk=mysqli_fetch_row($rd);      
    echo "<tr>
        <td class='text-center'>$row[0]</td>
        <td class='text-center'>$row[41]</td>
        <td class='hidden-xs'>$row[9] $row[11] $row[10]</td>
        <td class='hidden-xs'>$row[47]</td>
        <td class='hidden-xs'>$rk[0]</td>
        <td class='hidden-xs'>$row[4]</td><td class='hidden-xs'>$row[5]</td>
        <td class='hidden-xs'><a href='fees_details.php?id=$row[6]'>View Details</a></td>
        </tr>";
    
}

?>
