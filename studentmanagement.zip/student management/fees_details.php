<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
				
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter ">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<!--<th class="hidden-xs"> Admission ID</th>-->
							<th class="text-center">Class_Name</th>
							<th class="text-center">Student Name</th>
							<th class="text-center">Total Fees</th>
							<th class="hidden-xs"> Paid Amount</th>
							<th class="hidden-xs w-20"> Date</th>
							<th class="hidden-xs ">Remark </th>
						</tr>
					</thead>
					<tbody>
					<?php
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$id=$_GET['id'];
			
					$sql="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where fees_tbl.sid='$id'";
									
					$result=mysqli_query($con,$sql);
					$paid_fees=0;
					$total=0;
					while($row=mysqli_fetch_row($result))
					{
						$paid_fees+=$row[3];
						$total=$row[47];
						
					?>
						<tr>
							
							<td class="text-center"><?php echo $row[0];?></td>
							
								<td class="text-center"><?php echo $row[41];?></td>
							<td class="hidden-xs"><?php echo $row[9].' '.$row[11].' '.$row[10];?></td>
							<td class="hidden-xs"><?php echo $row[47];?></td>
							<td class="hidden-xs"><?php echo $row[3];?></td>
							<td class="hidden-xs"><?php echo $row[4];?></td>
							<td class="hidden-xs"><?php echo $row[5];?></td>
							
						</tr>
					<?php
					}
					$rem=$total-$paid_fees;
					?>
					</tbody>
				</table>
				<button class="btn btn-app" type="submit" name="sub" id="searchroll"><?php echo "Paid Fees Total:".$paid_fees."/-";?></button>
				<button class="btn btn-app" type="submit" name="sub" id="searchroll"><?php echo "Remaning Fees:".$rem."/-";?></button>
				
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>