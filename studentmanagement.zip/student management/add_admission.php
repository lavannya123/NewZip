<?php
if(isset($_POST['sub']))
{
$con=mysqli_connect('localhost', 'root', '', 'school_management');

$file=$_FILES['image']['name'];
$file_type=$_FILES['image']['type'];
$file_size=$_FILES['image']['size'];
$file_tmp=$_FILES['image']['tmp_name'];
$file_store='Student_Images/'.$file;


$file1=$_FILES['mother_signature_image']['name'];
$file_type1=$_FILES['mother_signature_image']['type'];
$file_size1=$_FILES['mother_signature_image']['size'];
$file_tmp1=$_FILES['mother_signature_image']['tmp_name'];
$file_store1='Student_Images/'.$file1;



$file2=$_FILES['father_signature_image']['name'];
$file_type2=$_FILES['father_signature_image']['type'];
$file_size2=$_FILES['father_signature_image']['size'];
$file_tmp2=$_FILES['father_signature_image']['tmp_name'];
$file_store2='Student_Images/'.$file2;

$applying_for=$_POST['applying_for'];
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$father_name=$_POST['father_name'];
$mother_name=$_POST['mother_name'];
$dob=$_POST['dob'];
$pob=$_POST['pob'];
$gender=$_POST['gender'];
$nationality=$_POST['nationality'];
$mother_tongue=$_POST['mother_tongue'];
$religion=$_POST['religion'];
$caste=$_POST['caste'];
$category=$_POST['category'];
$last_year_school=$_POST['last_year_school'];
$class=$_POST['class'];
$percentage=$_POST['percentage'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$state=$_POST['state'];
$country=$_POST['country'];
$mobile_no_1=$_POST['mobile_no_1'];
$mobile_no_2=$_POST['mobile_no_2'];
$phone_no=$_POST['phone_no'];
$adhar_no=$_POST['adhar_no'];


$guidance_father_name=$_POST['guidance_father_name'];
$father_age=$_POST['father_age'];
$father_education_qualification=$_POST['father_education_qualification'];
$father_occupation=$_POST['father_occupation'];
$father_annual_income=$_POST['father_annual_income'];
$father_email=$_POST['father_email'];
$father_office_address=$_POST['father_office_address'];
$father_mobile_no=$_POST['father_mobile_no'];

$guidance_mother_name=$_POST['guidance_mother_name'];
$mother_education_qualification=$_POST['mother_education_qualification'];
$mother_occupation=$_POST['mother_occupation'];
$mother_office_address=$_POST['mother_office_address'];
$mother_mobile_no=$_POST['mother_mobile_no'];


$total_no_of_family=$_POST['total_no_of_family'];
$place=$_POST['place'];
$date=$_POST['date'];

$documents="Null";

$family_info1 = array();
$father['father_name']=$guidance_father_name;
$father['father_age']=$father_age;
$father['father_education_qualification']=$father_education_qualification;
$father['father_occupation']=$father_occupation;
$father['father_annual_income']=$father_annual_income;
$father['father_email']=$father_email;
$father['father_office_address']=$father_office_address;
$father['father_mobile_no']=$father_mobile_no;
$data['father'] = $father;

$mother['mother_name']=$guidance_mother_name;
$mother['mother_education_qualification']=$mother_education_qualification;
$mother['mother_occupation']=$mother_occupation;
$mother['mother_office_address']=$mother_office_address;
$mother['mother_mobile_no']=$mother_mobile_no;
$data['mother'] = $mother;

array_push($family_info1,$data);
$family_info=json_encode($family_info1);

if(move_uploaded_file($file_tmp,$file_store))
{
if(move_uploaded_file($file_tmp1,$file_store1))
{
if(move_uploaded_file($file_tmp2,$file_store2))
{
$sql="INSERT INTO student_info (image,applying_for,first_name,last_name,father_name, mother_name, dob,place_of_birth,gender,nationality,religion,caste,category,mother_tongue, last_year_school,class,percentage,address,city,pin_code,state,country,mobile_no_1,mobile_no_2, phone_no,adhar_no,family_info,total_no_of_family,father_signature,mother_signature,place,date, documents) VALUES ('$file','$applying_for','$first_name','$last_name','$father_name','$mother_name','$dob','$pob','$gender','$nationality','$religion','$caste','$category','$mother_tongue','$last_year_school','$class','$percentage','$address','$city','$pincode','$state','$country','$mobile_no_1','$mobile_no_2','$phone_no','$adhar_no','$family_info','$total_no_of_family','$file2','$file1','$place','$date','$documents')";

if(mysqli_query($con,$sql))
{

$sql1="SELECT max(id) FROM student_info";


$r=mysqli_query($con,$sql1);
$w=mysqli_fetch_row($r);

$s=$w[0];
$sql2="INSERT INTO `admission_tbl`( `sid`, `cid`) VALUES ('$s','$applying_for')";
if(mysqli_query($con,$sql2))
{
echo"<script>alert('inserted...!');</script>";
//header("Location:add_joining.php");
}
else
{
echo"error".mysqli_error($con);
}
}
else
{
echo "Error".mysqli_error($con);
}
}
}
}




}
?>


<?php include 'header.php';?>
<main class="app-layout-content">
<div class="container-fluid p-y-md">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header">
<h4 style="border-style: solid;"><center>Student Information</center></h4>
<ul class="card-actions">
<li>
<button type="button"><i></i></button>
</li>
</ul>
</div>
<div class="card-block">
<form class="js-validation-bootstrap form-horizontal" method="post"  enctype="multipart/form-data">

<div class="form-group">
<label class="col-md-2 control-label" >Student Passsport Photo <span class="text-orange">*</span></label>
<div class="col-md-10">
<input type="file" id="image" name="image" />
</div>
</div>

<div class="form-group">

<label class="col-md-2 control-label" >Applying For <span class="text-orange">*</span></label>
<div class="col-md-10">
<?php
  $con=mysqli_connect('localhost','root','','school_management');
$sql="select * from class_tbl";
$rs=mysqli_query($con,$sql);
echo '<select class="form-control"  id="applying_for" name="applying_for" placeholder="Enter Class ID" required>';

echo "<option value=''>Select Class Name</option>";

while($rw=mysqli_fetch_row($rs))
{
echo "<option value='$rw[0]'>$rw[1]</option>";
}
echo "</select>";
?>

</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label" >First Name <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="first_name" name="first_name" placeholder="Enter First Name"/>
</div>

<label class="col-md-2 control-label" >Last Name <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="last_name" name="last_name" placeholder="Enter Last Name">
</div>

<label class="col-md-2 control-label" >Father Name <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="father_name" name="father_name" placeholder="Enter Father Name">
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Mothers Name <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="mother_name" name="mother_name" placeholder="Enter Mothers Name"/>
</div>

<label class="col-md-2 control-label">Date of Birth  <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="date" id="dob" name="dob" >
</div>

<label class="col-md-2 control-label">place of Birth <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="pob" name="pob" placeholder="Enter Place of birth ">
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label" >Gender <span class="text-orange">*</span></label>
<div class="col-md-2">
 <input class="form" type="radio" value="male" id="gender" name="gender"  /> &nbsp Male &nbsp
 <input class="form" type="radio" value="female" id="gender" name="gender" />&nbsp Female
</div>


<label class="col-md-2 control-label" >Nationality <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="nationality" name="nationality" placeholder="Enter Nationality ">
</div>


<label class="col-md-2 control-label" >Mother Tongue <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="mother_tongue" name="mother_tongue" placeholder="Enter Mother Tongue ">
</div>

</div>

<div class="form-group">
<label class="col-md-2 control-label">Religion <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="religion" name="religion" placeholder="Enter Religion ">
</div>

<label class="col-md-2 control-label" >Caste <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="caste" name="caste" placeholder="Enter Caste ">
</div>

<label class="col-md-2 control-label" >Category <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="category" name="category" placeholder="Enter Category">
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label">Name of last Year School<span class="text-orange">*</span></label>
<div class="col-md-10">
<input class="form-control" type="text" id="last_year_school" name="last_year_school" placeholder="Enter Name of last Year school" />
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Class <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="class" name="class" placeholder="Enter Class ">
</div>

<label class="col-md-2 control-label" >Percentage <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="percentage" name="percentage" placeholder="Enter Percentage ">
</div>

</div>


<div class="form-group">
<label class="col-md-2 control-label" >Residential Address<span class="text-orange">*</span></label>
<div class="col-md-4">
<textarea class="form-control"  id="address" name="address" placeholder="Enter Address" /></textarea>
</div>

<label class="col-md-2 control-label">City <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="city" name="city" placeholder="Enter City ">
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Pincode <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="pincode" name="pincode" placeholder="Enter pincode ">
</div>

<label class="col-md-2 control-label" >State <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="state" name="state" placeholder="Enter Caste ">
</div>

<label class="col-md-2 control-label">Country <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="country" name="country" placeholder="Enter Country">
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label" >Mobile No <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="mobile_no_1" name="mobile_no_1" placeholder="Enter Mobile no ">
</div>

<label class="col-md-2 control-label" >Alternate Mobile No <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="mobile_no_2" name="mobile_no_2" placeholder="Enter Alternate Mobile No ">
</div>

<label class="col-md-2 control-label">Phone No <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="phone_no" name="phone_no" placeholder="Enter Phone No">
</div>
</div>



<div class="form-group">
<label class="col-md-2 control-label">Adhar Card No<span class="text-orange">*</span></label>
<div class="col-md-10">
<input class="form-control" type="text" id="adhar_no" name="adhar_no" placeholder="Enter Adhar No" />
</div>
</div>



<div class="card-header">
<h4 style="border-style: solid;"><center>Family Information</center></h4>
<ul class="card-actions">
<li>
<button type="button"><i></i></button>
</li>
</ul>
</div>

<div class="card-header">
<h4>Fathers Info</h4>
<ul class="card-actions">
<li>
<button type="button"><i></i></button>
</li>
</ul>
</div>

<div class="form-group">
<label class="col-md-2 control-label" >Father Name<span class="text-orange">*</span></label>
<div class="col-md-10">
<input class="form-control" type="text" id="guidance_father_name" name="guidance_father_name" placeholder="Enter Father Name" />
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label">Fathers Age <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="father_age" name="father_age" placeholder="Enter Age ">
</div>

<label class="col-md-2 control-label">Eucation Qualification <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="father_education_qualification" name="father_education_qualification" placeholder="Enter  Education Qualification ">
</div>

<label class="col-md-2 control-label" >Occupation <span class="text-orange">*</span></label>
<div class="col-md-2">
<input class="form-control" type="text" id="father_occupation" name="father_occupation" placeholder="Enter Occupation">
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label" >Annual Income <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="father_annual_income" name="father_annual_income" placeholder="Enter Annual Income ">
</div>

<label class="col-md-2 control-label">Email <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="email" id="father_email" name="father_email" placeholder="Enter Email ">
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Office Address <span class="text-orange">*</span></label>
<div class="col-md-4">
<textarea class="form-control" type="text" id="father_office_address" name="father_office_address" placeholder="Enter Office Adress "></textarea>
</div>

<label class="col-md-2 control-label" >Mobile No <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="father_mobile_nofather_mobile_nofather_mobile_no" name="father_mobile_no" placeholder="Enter Mobile_no ">
</div>
</div>


<div class="card-header">
<h4>Mothers Info</h4>
<ul class="card-actions">
<li>
<button type="button"><i></i></button>
</li>
</ul>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Mother Name<span class="text-orange">*</span></label>
<div class="col-md-10">
<input class="form-control" type="text" id="guidance_mother_name" name="guidance_mother_name" placeholder="Enter Mother Name" />
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Education Qualification <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="mother_education_qualification" name="mother_education_qualification" placeholder="Enter Education Qualification ">
</div>

<label class="col-md-2 control-label" >Occupation <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="mother_occupation" name="mother_occupation" placeholder="Enter Occupation ">
</div>

</div>

<div class="form-group">
<label class="col-md-2 control-label" >Office Address <span class="text-orange">*</span></label>
<div class="col-md-4">
<textarea class="form-control" type="text" id="mother_office_address" name="mother_office_address" placeholder="Enter Office Adress "></textarea>
</div>

<label class="col-md-2 control-label" >Mobile No <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="mother_mobile_no" name="mother_mobile_no" placeholder="Enter Mobile_no ">
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label"><a data-toggle="modal" data-target="#modal-terms" href="#">Terms</a> <span class="text-orange">*</span></label>
<div class="col-md-8">
<label class="css-input css-checkbox css-checkbox-default" for="val-terms">
<input type="checkbox" id="val-terms" name="val-terms" value="1" /><span></span> I agree and Accept the school Rules and Regulations
</label>
</div>
</div>

<div class="form-group">
<label class="col-md-2 control-label">Total No of Stuents<span class="text-orange">*</span></label>
<div class="col-md-10">
<input class="form-control" type="text" id="total_no_of_family" name="total_no_of_family" placeholder="Enter Total No of Students" />
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Father Signature Photo <span class="text-orange">*</span></label>
<div class="col-md-3">
<input type="file" id="father_signature_image" name="father_signature_image" />
</div> &nbsp &nbsp

<label class="col-md-2 control-label" >Mother Signature Photo <span class="text-orange">*</span></label>
<div class="col-md-2">
<input type="file" id="mother_signature_image" name="mother_signature_image" />
</div>
</div>


<div class="form-group">
<label class="col-md-2 control-label" >Place <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="text" id="place" name="place" placeholder="Enter Place">
</div>

<label class="col-md-2 control-label" >Date <span class="text-orange">*</span></label>
<div class="col-md-4">
<input class="form-control" type="date" id="date" name="date" >
</div>

</div>

<div class="form-group m-b-0">
<div class="col-md-8 col-md-offset-4">
<button class="btn btn-app" type="submit" name="sub">Submit</button>
</div>
</div>

</form>
</div>
</div>
</div>
</div>





<div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-dialog-popin">
<div class="modal-content">
<div class="card m-b-0">
<div class="card-header bg-app bg-inverse">
<h4>Terms &amp; Conditions</h4>
<ul class="card-actions">
<li>
<button data-dismiss="modal" type="button"><i class="ion-close"></i></button>
</li>
</ul>
</div>
<div class="card-block">
<h4 class="m-t">1. <strong>General</strong></h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
Integer fermentum tincidunt auctor.</p>
<h4>2. <strong>Account</strong></h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
Integer fermentum tincidunt auctor.</p>
</div>
</div>
<div class="modal-footer">
<button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
<button class="btn btn-sm btn-app" type="button" data-dismiss="modal"><i class="ion-checkmark"></i> Ok</button>
</div>
</div>
</div>
</div>
</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="assets/js/pages/base_forms_validation.js"></script>

    </body>

</html>