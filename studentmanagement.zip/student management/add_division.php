<?php
$con=mysqli_connect('localhost', 'root', '', 'school_management');
if(isset($_POST['sub']))
{
	
	$class_name=$_POST['class_name'];
	$div=$_POST["div_name"];
	if($div!=null)
	{
		$sql="INSERT INTO div_tbl(class_id,div_name) VALUES ('$class_name','$div')";
		if(mysqli_query($con,$sql))
		{
			header("Location:add_division.php");
		}
		else
		{
			echo"error".mysqli_error($con);
		}
	}
	else
	{
		echo "<script>alert('Enter Division Name')</script>";
	}
}	
?>
	
<?php include 'header.php';?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="row">
			<div class="col-lg-8">
				<div class="card">
					<div class="card-header">
						<h2>Class Divisions</h2>
						<ul class="card-actions">
							<li>
								<button type="button"><i></i></button>
							</li>
						</ul>
					</div>
					<div class="card-block">
						<form class="js-validation-bootstrap form-horizontal" method="post">
                        <div class="form-group">
								<label class="col-md-2 control-label" >Class Name <span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<select class="form-control" type="text" id="class_name" name="class_name">
                                    <?php
                                    $sq="select * from class_tbl";
                                    $rs=mysqli_query($con,$sq);
                                    while($rk=mysqli_fetch_row($rs))
                                    {
                                    ?>    
                                    <option value="<?php echo $rk[0];?>"><?php echo $rk[1];?></option>
                                    <?php
                                    }
                                    ?>
                                    </select>
								</div>
							</div>
                            <div class="form-group">
								<label class="col-md-2 control-label" >Division Name <span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<input class="form-control" type="text" id="class_name" name="div_name" placeholder="Enter Division"/>
								</div>
							</div>
							
							<div class="form-group">
								<div class="form-group m-b-0">
									<div class="col-md-8 col-md-offset-4">
										<button class="btn btn-app" type="submit" name="sub">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
		
		
		
		<div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-dialog-popin">
				<div class="modal-content">
					<div class="card m-b-0">
						<div class="card-header bg-app bg-inverse">
							<h4>Terms &amp; Conditions</h4>
							<ul class="card-actions">
								<li>
									<button data-dismiss="modal" type="button"><i class="ion-close"></i></button>
								</li>
							</ul>
						</div>
						<div class="card-block">
							<h4 class="m-t">1. <strong>General</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
							<h4>2. <strong>Account</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
						</div>
					</div>
					<div class="modal-footer">
						<button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
						<button class="btn btn-sm btn-app" type="button" data-dismiss="modal"><i class="ion-checkmark"></i> Ok</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
<main class="app-layout-content" style="margin-top:-100px;">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th>Class Name</th>
							<th>Division Name</th>
							<!--<th class="hidden-xs"> Status</th>
							<th class="hidden-xs w-20">Date </th>-->
							<th class="text-center" style="width: 10%;">Edit</th>
							<th class="text-center" style="width:10%;">Delete</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$i=1;
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$sql="select * from div_tbl inner join class_tbl on div_tbl.class_id=class_tbl.id";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
					?>
						<tr>
							<td class="text-center"><?php echo $i;?></td>
							<td class="font-500"><?php echo $row['class'] ;?></td>
							
							<td class="hidden-xs"><?php echo $row['div_name'];?></td>
							<!--<td class="hidden-xs"><?php //echo $row['date'];?></td>-->
							
							<td class="text-center">
								
									<a href="edit_div.php?id=<?php echo $row['id'];?>"  class="btn btn-xs btn-default" type="button" " title="Edit Client"><i class="ion-edit"></i></a>
									<!--<a href="class_details.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button"  title="Views Client"><i class="fa fa-eye"></i></a>-->
								
							</td>
							<td class="text-center">
							<a href="delete_division.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button" title="Remove Client"><i class="ion-close"></i></a>
								

							</td>
						</tr>
					<?php
					$i++;
					}
					
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
</div>
</div>
	<div class="app-ui-mask-modal"></div>
	<script src="assets/js/core/jquery.min.js"></script>
	<script src="assets/js/core/bootstrap.min.js"></script>
	<script src="assets/js/core/jquery.slimscroll.min.js"></script>
	<script src="assets/js/core/jquery.scrollLock.min.js"></script>
	<script src="assets/js/core/jquery.placeholder.min.js"></script>
	<script src="assets/js/app.js"></script>
	<script src="assets/js/app-custom.js"></script>
	<script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
	<script src="assets/js/pages/base_forms_validation.js"></script>
	<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>

    </body>

</html>