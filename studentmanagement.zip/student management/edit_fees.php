<?php
$con=mysqli_connect('localhost', 'root', '', 'school_management');
if(isset($_POST['sub']))
{
	
	$id=$_GET['id'];
	$pamount=$_POST['pamount'];	
	$student_name=$_POST['student_name'];
	$class_id=$_POST['class_id'];
	
	$date=$_POST['date'];
	$remark=$_POST['remark'];
	
	
		$sql="update `fees_tbl` set `paid_fees`='$pamount', `sid`='$student_name', `cid`='$class_id', `date`='$date', `remark`='$remark' where id='$id'";
			if(mysqli_query($con,$sql))
			{
				//echo"inserted...!";
				header("Location:add_fees.php");
			}
			else
			{
				echo "error".mysqli_error($con);
			}
		
	
	
	
	
	
	

}	
?>
	
<?php include 'header.php';?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<h4 style="border-style: solid;"><center>Fees Information</center></h4>
						
					</div>
					<div class="card-block">
						<form class="js-validation-bootstrap form-horizontal" method="post" >
						
							<?php
							$con=mysqli_connect('localhost', 'root', '', 'school_management');
							$id=$_GET['id'];
							$sql="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where fees_tbl.id='$id' ";
							$result=mysqli_query($con,$sql);
							
							while($row=mysqli_fetch_row($result))
							{
						?>
							
						
							
							<div class="form-group">
								<label class="col-md-2 control-label" >Student Name <span class="text-orange">*</span></label>
								<div class="col-lg-10">
											<?php
									           
												$sql1="select * from admission_tbl inner join student_info on admission_tbl.sid=student_info.id";
												$rs1=mysqli_query($con,$sql1);
												echo '<select class="form-control"  id="student_name" name="student_name" placeholder="Enter Student Name">';
												
												echo "<option value='$row[6]'>$row[9] $row[11] $row[10]</option>";
												
												while($rw1=mysqli_fetch_row($rs1))
												{
												echo "<option value='$rw1[6]'> $rw1[10] $rw1[12] $rw1[11]</option>";
												}
												echo "</select>"; 
											?>
									
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" >Class Name<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<?php
									          
												$sql2="SELECT * FROM class_tbl";
												$rs=mysqli_query($con,$sql2);
												echo '<select class="form-control"  id="class_id" name="class_id" placeholder="Enter Class ID">';
												
												echo "<option value='$row[40]'>$row[41] </option>";
												
												
												while($rw=mysqli_fetch_row($rs))
												{
												echo "<option value='$rw[0]'>$rw[1]</option>";
												}
												echo "</select>"; 
											?>
									
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-md-2 control-label" >Paid Amount<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<input class="form-control" type="text" value="<?php echo $row[3];?>" id="pamount" name="pamount" placeholder="Enter Paid Amount "/>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" >date<span class="text-orange">*</span></label>
								
								<div class="col-lg-10">
									<input class="form-control"  type="date" id="date" name="date" value="<?php echo $row[4];?>" placeholder="Enter  Date"/>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" >Remark<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<input class="form-control" value="<?php echo $row[5];?>" type="text" id="remark" name="remark" placeholder="Enter Remark"/>
								</div>
							</div>
							
							<!--<div class="form-group">
								<label class="col-md-2 control-label" >status<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<select class="form-control"  id="status" name="status" placeholder="Enter Last Name">
									<option value="Active">Active</option>
									<option value="Inactive">Inactive</option>
									</select>
								</div>
							</div>-->
							<?php
								}
							?>
							<div class="form-group">
								
								<div class="form-group m-b-0">
									<div class="col-md-8 col-md-offset-4">
										<button class="btn btn-app" type="submit" name="sub">Update</button>
									</div>
								</div>
								
							</div>
							
							
							
							
							
						
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
		
		
		
		<div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-dialog-popin">
				<div class="modal-content">
					<div class="card m-b-0">
						<div class="card-header bg-app bg-inverse">
							<h4>Terms &amp; Conditions</h4>
							<ul class="card-actions">
								<li>
									<button data-dismiss="modal" type="button"><i class="ion-close"></i></button>
								</li>
							</ul>
						</div>
						<div class="card-block">
							<h4 class="m-t">1. <strong>General</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
							<h4>2. <strong>Account</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
						</div>
					</div>
					<div class="modal-footer">
						<button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
						<button class="btn btn-sm btn-app" type="button" data-dismiss="modal"><i class="ion-checkmark"></i> Ok</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
</div>
</div>
	<div class="app-ui-mask-modal"></div>
	<script src="assets/js/core/jquery.min.js"></script>
	<script src="assets/js/core/bootstrap.min.js"></script>
	<script src="assets/js/core/jquery.slimscroll.min.js"></script>
	<script src="assets/js/core/jquery.scrollLock.min.js"></script>
	<script src="assets/js/core/jquery.placeholder.min.js"></script>
	<script src="assets/js/app.js"></script>
	<script src="assets/js/app-custom.js"></script>
	<script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
	<script src="assets/js/pages/base_forms_validation.js"></script>

    </body>

</html>