<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th>Class Name</th>
							
							<!--<th class="hidden-xs"> Status</th>
							<th class="hidden-xs w-20">Date </th>-->
							<th class="text-center" style="width: 10%;">Edit</th>
							<th class="text-center" style="width:10%;">Delete</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$i=1;
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$sql="select * from class_tbl";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
					?>
						<tr>
							<td class="text-center"><?php echo $i;?></td>
							<td class="font-500"><?php echo $row['class'] ;?></td>
							
							<!--<td class="hidden-xs"><?php// echo $row['status'];?></td>
							<td class="hidden-xs"><?php //echo $row['date'];?></td>-->
							
							<td class="text-center">
								
									<a href="edit_class.php?id=<?php echo $row['id'];?>"  class="btn btn-xs btn-default" type="button" " title="Edit Client"><i class="ion-edit"></i></a>
									<!--<a href="class_details.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button"  title="Views Client"><i class="fa fa-eye"></i></a>-->
								
							</td>
							<td class="text-center">
							<a href="delete_class.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button" title="Remove Client"><i class="ion-close"></i></a>
								

							</td>
						</tr>
					<?php
					$i++;
					}
					
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>