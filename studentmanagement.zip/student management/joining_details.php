<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter ">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th class="text-center">Student Name</th>
							<th class="text-center">Class Name</th>
							<th class="hidden-xs w-20"> Date</th>
							<th class="hidden-xs "> Status</th>
							<!--<th class="text-center" style="width: 10%;">Actions</th>-->
							
							
						</tr>
					</thead>
					<tbody>
					<?php
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$id=$_GET['id'];
					
					$sql="SELECT *
									FROM admission_tbl
									INNER JOIN student_info ON admission_tbl.sid = student_info.id
									INNER JOIN class_tbl ON admission_tbl.cid = class_tbl.id where admission_tbl.id='$id'";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_row($result))
					{
					?>
					?>
						<tr>
							<td class="text-center"><?php echo $row[0];?></td>
							<td class="font-500"><?php echo $row[9].' '.$row[10].' '.$row[11];?> </td>
							<td class="hidden-xs"><?php echo $row[40];?></td>
							<td class="hidden-xs"><?php echo $row[4];?></td>
							<td class="hidden-xs"><?php echo $row[3];?></td>
							
						</tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>