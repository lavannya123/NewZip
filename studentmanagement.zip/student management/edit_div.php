<?php
if(isset($_POST['sub']))
{
	$con=mysqli_connect('localhost', 'root', '', 'school_management');
	$class_name=$_POST['class_name'];
    $div=$_POST['div_name'];
	$status=$_POST['status'];
	$id=$_GET['id'];
	if($div!=null)
	{
		$sql="update `div_tbl` set `class_id`='$class_name',`div_name`='$div',`status`='$status' where id='$id'";
		if(mysqli_query($con,$sql))
		{
			//echo"inserted...!";
			header("Location:add_division.php");
		}
		else
		{
			echo"error".mysqli_error($con);
		}
		
	}
	else
	{
		echo "<script>alert('Enter Division Name')</script>";
	}

}	
?>

<?php include 'header.php';?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<h4 style="border-style: solid;"><center>Class Information</center></h4>
						<ul class="card-actions">
							<li>
								<button type="button"><i></i></button>
							</li>
						</ul>
					</div>
					<div class="card-block">
						<form class="js-validation-bootstrap form-horizontal" method="post"  >
				
						<?php
							$con=mysqli_connect('localhost', 'root', '', 'school_management');
							$id=$_GET['id'];
							$sql="select * from div_tbl inner join class_tbl on div_tbl.class_id=class_tbl.id where div_tbl.id='$id'";
							$result=mysqli_query($con,$sql);
							while($row=mysqli_fetch_array($result))
							{
						?>
						
							<div class="form-group">
								<label class="col-md-2 control-label" >Class Name <span class="text-orange">*</span></label>
								<div class="col-lg-10">
                                    <select class="form-control" type="text" id="class_name" name="class_name">
                                        <option value="<?php echo $row['class_id'];?>"><?php echo $row['class'];?></option>
                                        <?php
                                    $sq="select * from class_tbl";
                                    $rs=mysqli_query($con,$sq);
                                    while($rk=mysqli_fetch_row($rs))
                                    {
                                    ?>    
                                    <option value="<?php echo $rk[0];?>"><?php echo $rk[1];?></option>
                                    <?php
                                    }
                                    ?>

								</div>
							</div>
							<div class="form-group">
							<label class="col-md-2 control-label" >Division Name<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<input class="form-control" type="text" id="class_name" name="div_name" placeholder="Enter Division" value="<?php echo $row['div_name'];?>">
								</div>
							</div>
							
							
							<div class="form-group">
								<label class="col-md-2 control-label" >status<span class="text-orange">*</span></label>
								<div class="col-lg-10">
									<select class="form-control"  id="status" name="status" placeholder="Enter Last Name">
									<option value="	<?php echo $row['status']; ?>"><?php echo $row['status']; ?></option>
									<option value="Active">Active</option>
									<option value="Inactive">Inactive</option>
									</select>
								</div>
							
							</div>
							<div class="form-group">
								
								<div class="form-group m-b-0">
									<div class="col-md-8 col-md-offset-4">
										<button class="btn btn-app" type="submit" name="sub">Update</button>
									</div>
								</div>
								
							</div>
							
							<?php
								}
							?>
							
							
							
						
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
		
		
		
		<div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-dialog-popin">
				<div class="modal-content">
					<div class="card m-b-0">
						<div class="card-header bg-app bg-inverse">
							<h4>Terms &amp; Conditions</h4>
							<ul class="card-actions">
								<li>
									<button data-dismiss="modal" type="button"><i class="ion-close"></i></button>
								</li>
							</ul>
						</div>
						<div class="card-block">
							<h4 class="m-t">1. <strong>General</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
							<h4>2. <strong>Account</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices, justo vel imperdiet gravida, urna ligula hendrerit nibh, ac cursus nibh sapien in purus. Mauris tincidunt tincidunt turpis in porta.
								Integer fermentum tincidunt auctor.</p>
						</div>
					</div>
					<div class="modal-footer">
						<button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
						<button class="btn btn-sm btn-app" type="button" data-dismiss="modal"><i class="ion-checkmark"></i> Ok</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
</div>
</div>
	<div class="app-ui-mask-modal"></div>
	<script src="assets/js/core/jquery.min.js"></script>
	<script src="assets/js/core/bootstrap.min.js"></script>
	<script src="assets/js/core/jquery.slimscroll.min.js"></script>
	<script src="assets/js/core/jquery.scrollLock.min.js"></script>
	<script src="assets/js/core/jquery.placeholder.min.js"></script>
	<script src="assets/js/app.js"></script>
	<script src="assets/js/app-custom.js"></script>
	<script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
	<script src="assets/js/pages/base_forms_validation.js"></script>

    </body>

</html>