<?php
$con=mysqli_connect("localhost","root","","school_management");
$id=$_GET['id'];
$delete="delete from student_info where id=$id";
if(mysqli_query($con,$delete))
{
	header('location:admission_list.php');
}
?>