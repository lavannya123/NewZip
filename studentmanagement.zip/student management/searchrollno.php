<?php
$id=$_GET["id"];
//echo $id;
$con=mysqli_connect('localhost', 'root', '', 'school_management');
$sql="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where student_info.id='$id' GROUP BY fees_tbl.sid";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_row($result))
{
    echo "<tr>
    <td class='text-center'>$row[0]</td>
    
        <td class='text-center'>$row[42]</td>
    <td class='hidden-xs'>$row[12] $row[11] $row[13]</td>
    
    <td class='hidden-xs'>$row[3]</td>
    <td class='hidden-xs'>$row[48]</td>
    <td class='hidden-xs'>$row[49]</td>
    <td class='hidden-xs'>$row[4]</td>
    <td class='hidden-xs'>$row[5]</td><td class='hidden-xs'>$row[6]</td>
    <td class='hidden-xs'><a href='fees_details.php?id=$row[7]'>View Details</a></td>
    </tr>";
}
?>