<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th>Full Name</th>
							<th class="hidden-xs">Applying For</th>
							<th class="hidden-xs w-20">Mother Name</th>
							<th class="hidden-xs w-20">Date Of Birth</th>
							<th class="text-center" style="width: 10%;">Actions</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
				
					$sql="select * from student_info ";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
					?>
						<tr>
							<td class="text-center"><?php echo $row['id'];?></td>
							<td class="font-500"><?php echo $row['first_name']." ".$row['last_name']." ".$row['father_name'];?></td>
							<td class="hidden-xs"><?php echo $row['applying_for'];?></td>
							<td class="hidden-xs"><?php echo $row['mother_name'];?></td>
							<td class="hidden-xs"><?php echo $row['dob'];?></td>
							<td class="text-center">
								<div class="btn-group">
									<a href="edit_admission.php?id=<?php echo $row['id'];?>"  class="btn btn-xs btn-default" type="button" data-toggle="tooltip" title="Edit Client"><i class="ion-edit"></i></a>
									<a href="delete_admission.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button" data-toggle="tooltip" title="Remove Client"><i class="ion-close"></i></a>
									<a href="admission_details.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-default" type="button" data-toggle="tooltip" title="Views Client"><i class="fa fa-eye"></i></a>
								</div>
							</td>
						</tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>