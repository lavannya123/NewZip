<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Fees Collection Report</h4>
			</div>
			
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter ">
				<div style="text-align: right; max-width: 100%;">
					<?php
									$con=mysqli_connect('localhost','root','','school_management');
									$sql="select * from class_tbl";
									$rs=mysqli_query($con,$sql);
									echo "Class <select data-placeholder='Choose a department...'  class='standardSelect ' tabindex='1' name='class' id='cid' required>";
									echo "<option value=''>Select Class</option>";
									while($rw=mysqli_fetch_row($rs))
									{
										echo "<option value='$rw[0]'>$rw[1]</option>";
									}
									echo "</select>";
								 ?>
								 
				</div>
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<!--<th class="hidden-xs"> Admission ID</th>-->
							<th class="hidden-xs">Class_Name</th>
							<th class="hidden-xs">Student Name</th>							
							<th class="hidden-xs w-20">Total Fees</th>
							<th class="hidden-xs">Paid Fees</th>
							<th class="hidden-xs ">Pending Fees</th>
							<th class="text-center" style="width: 11%;">Actions</th>
						</tr>
					</thead>
					<tbody id="tbodyid">
					<?php
					//$con=mysqli_connect('localhost', 'root', '', 'school_management');
					/*$sql="SELECT * FROM fees_tbl";
					$rs=mysqli_query($con,$sql);
					while($rw=mysqli_fetch_row($rs))
					{
						$sid=$rw[4];
						$class_id=$rw[5];
						$sq="SELECT MAX(id),fees_type,amt,sid,class_id,date,remark,MAX(paid_amt) FROM fees_tbl WHERE sid = '$rw[4]' and class_id='$rw[5]'";
						$rp=mysqli_query($con,$sq);
						$r=mysqli_fetch_row($rp);
							
					}
					echo $m=$r[0];
					echo $l=$r[3];
					$rp=mysqli_query($con,$sq);
					$r=mysqli_fetch_row($rp);
					*/
					// $sqm="SELECT count(fees_tbl.sid), from fees_tbl inner join student_info as s on fees_tbl.sid=s.id inner join class_tbl as c on fees_tbl.class_id=c.id ";
					// $rl=mysqli_query($con,$sqm);
						//$bg=mysqli_fetch_row($rl);
						//echo $bg[0];
					//exit();
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script  type="text/javascript">
	$(document).ready(function(){
		$("#cid").on("change",function (){
			id=$(this).val();
			//alert(id);
			$.ajax({
				url:"fees_class.php?id="+id,
				method:"get",
				success:function(data)
				{
					alert(data);
					var test=data.split('::');
					var m="<tr><td>"+test[0]+"</td><td>"+test[1]+"</td><td>"+test[2]+"</td><td>"+test[3]+"</td><td>"+test[4]+"</td><td>"+test[5]+"</td><td><a href='view_details.php?sid_id="+test[6
					]&& test[7]+"'  type='button'  title='Views Client'>View</a><td></tr>";
					$("#tbodyid").append(m);
				},
				error: function(data)
				{
					alert(data);
				}
			});
		});
	});

</script>
</body>

</html>