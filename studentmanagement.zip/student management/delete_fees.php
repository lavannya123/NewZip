<?php
$con=mysqli_connect("localhost","root","","school_management");
$id=$_GET['id'];
$delete="delete from fees_tbl where id='$id'";
if(mysqli_query($con,$delete))
{
	header('location:add_fees.php');
}
?>