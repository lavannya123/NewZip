<?php include "header.php";
$con=mysqli_connect('localhost', 'root', '', 'school_management');

?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="row">
			<div class="col-lg-12">
			<div class="form-group">
			<label class="col-md-4 control-label" >Class Name<span class="text-orange">*</span></label>
			<label class="col-md-4 control-label" ><span class="text-orange"></span></label>
			<label class="col-md-4 control-label" ><span class="text-orange" style="color:#fbfaf8">*</span></label>

			
</div>
<div>
								<div class="col-lg-4">
									<?php
									          
												$sql2="SELECT * FROM class_tbl";
												$rs=mysqli_query($con,$sql2);
												echo '<select class="form-control"  id="class_id" name="class_id" placeholder="Enter Class ID">';
												
												echo "<option value=''>Select Class Name</option>";
												
												
												while($rw=mysqli_fetch_row($rs))
												{
												echo "<option value='$rw[0]'>$rw[1]</option>";
												}
												echo "</select>"; 
											?>
									
								</div>
							</div>
								<!--<div class="col-lg-4">
									<input type="text" class="form-control"  id="roll_id" placeholder="Enter Roll Number" value="">
								</div>
								<div class="col-lg-4">
									<?php
									          
											/*	$sql2="SELECT * FROM class_tbl";
												$rs=mysqli_query($con,$sql2);
												echo '<select class="form-control"  id="class_id" name="class_id" placeholder="Enter Class ID">';
												
												echo "<option value=''>Select Class Name</option>";
												
												
												while($rw=mysqli_fetch_row($rs))
												{
												echo "<option value='$rw[0]'>$rw[1]</option>";
												}
												echo "</select>"; */
											?>
									
								</div>-->
								
					<br><br>
					<div class="col-lg-12">
					<div class="col-lg-4">
					<div class="form-group">
						<br>
								<button class="btn btn-app" type="submit" name="sub" id="searchclass">Search</button>
					</div>
					</div>
					<!--<div class="col-lg-4">
					<div class="form-group">
					<br>
								<button class="btn btn-app" type="submit" name="sub" id="searchroll">Search</button>

			
</div>
											</div>-->
											
		</div>
											</div>
											</div>
		
		<div class="card" id="classdatatbl" style='display:none;'>
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
				<button class="btn btn-primary">Total Class Fees:- <p id="totalclass"></p></button>
				<button class="btn btn-primary" style="margin-left:40px;">Total Class Paid Fees:- <p id="totalclasspaid"></p></button>
				<button class="btn btn-primary"  style="margin-left:40px;" id="pendingfees">Total Class Pending Fees:- <p id="totalclasspending"></p></button>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th class="text-center">Class_Name</th>
							<th class="text-center">Student Name</th>
							<th class="text-center">Total Fees</th>
							<th class="hidden-xs"> Paid Fees</th>
							<th class="hidden-xs w-20"> Date</th>
							<th class="hidden-xs ">Remark </th>
							<th class="text-center">Details Fees</th>
						</tr>
					</thead>
					<tbody id="classdata">
						
						
					</tbody>
				</table>
			</div>
		</div>
		<div class="card" id="pendinglist" style='display:none;'>
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
				
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th class="text-center">Class_Name</th>
							<th class="text-center">Student Name</th>
							<th class="text-center">Total Fees</th>
							<th class="hidden-xs"> Paid Fees</th>
							<th class="text-center">Pending Fees</th>
						</tr>
					</thead>
					<tbody id="classpending">
						
						
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <script>
		$(document).ready(function(){
			$("#searchclass").on("click",function(){
				var id=$("#class_id").val();
				$.ajax({
					url:'searchclass.php?id='+id,
					method:'get',
					success:function(data)
					{
						document.getElementById("classdatatbl").style.cssText = "display:block;width:100%;";
						$("#classdata").html(data);
						$.ajax({
							url:'searchtotal.php?id='+id,
							method:'get',
							success:function(data)
							{
								var test=data.split("::");
								document.getElementById("totalclass").innerHTML=test[0];
								document.getElementById("totalclasspaid").innerHTML=test[1];
								document.getElementById("totalclasspending").innerHTML=test[2];
								
							},
							error:function(data)
							{
								alert(data);
							}
						});

					},
					error:function(data)
					{
						alert(data);
					}
				});
			});
			$("#pendingfees").on("click",function(){
				var id=$("#class_id").val();
				//alert(id);
				$.ajax({
					url:'searchpendingfees.php?id='+id,
					method:'get',
					success:function(data)
					{
						document.getElementById("classdatatbl").style.cssText = "display:none;";
						document.getElementById("pendinglist").style.cssText = "display:block;width:100%;";
						$("#classpending").html(data);
					},
					error:function(data)
					{
						alert(data);
					}
				});
			});
			/*$("#searchroll").on("click",function(){
				var id=$("#roll_id").val();
				$.ajax({
					url:'searchrollno.php?id='+id,
					method:'get',
					success:function(data)
					{
						document.getElementById("classdatatbl").style.cssText = "display:block;width:100%;";
						$("#classdata").html(data);
					},
					error:function(data)
					{
						alert(data);
					}
				});
			});*/
		});
	</script>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>