<?php include "header.php";?>
<main class="app-layout-content">
	<div class="container-fluid p-y-md">
		<div class="card">
			<div class="card-header">
				<h4>Dynamic Table - Full</h4>
			</div>
			<div class="card-block">
				<table class="table table-bordered table-striped table-vcenter ">
					<thead>
						<tr>
							<th colspan="2" class="text-center">Student Details<th>
						
						</tr>
					</thead>
					<tbody>
					<?php 
				
					$con=mysqli_connect('localhost', 'root', '', 'school_management');
					$id=$_GET['id'];
					$sql="select * from student_info where id='$id'";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_row($result))
					{
					?>
						<tr><td class="font-500 text-center">ID</td><td class="hidden-xs"><?php echo $row[0];?></td></tr>
						<tr><td class="font-500 text-center">Image</td><td class="hidden-xs"><img src="Student_Images/<?php echo $row[1]?>" height=70 width=70></td></tr>
						<tr><td class="font-500 text-center">Applying For</td><td class="hidden-xs"><?php echo $row[2];?></td></tr>
						<tr><td class="font-500 text-center w-20">Full Name</td><td class="hidden-xs"><?php echo $row[4]." ".$row[3]." ".$row[5];?></td></tr>
						<tr><td class="font-500 text-center">Mother Name</td><td class="hidden-xs"><?php echo $row[6];?></td></tr>
						<tr><td class="font-500 text-center">Date Of Birth</td><td class="hidden-xs"><?php echo $row[7];?></td></tr>
						<tr><td class="font-500 text-center">Place Of Birth</td><td class="hidden-xs"><?php echo $row[8];?></td></tr>
						<tr><td class="font-500 text-center">Gender</td><td class="hidden-xs"><?php echo $row[9];?></td></tr>
						<tr><td class="font-500 text-center">Nationality</td><td class="hidden-xs"><?php echo $row[10];?></td></tr>
						<tr><td class="font-500 text-center">Religion</td><td class="hidden-xs"><?php echo $row[11];?></td></tr>
						<tr><td class="font-500 text-center">Caste</td><td class="hidden-xs"><?php echo $row[12];?></td></tr>
						<tr><td class="font-500 text-center">Category</td><td class="hidden-xs"><?php echo $row[13];?></td></tr>
						<tr><td class="font-500 text-center">Mother Tongue</td><td class="hidden-xs"><?php echo $row[14];?></td></tr>
						<tr><td class="font-500 text-center">Last Year School</td><td class="hidden-xs"><?php echo $row[15];?></td></tr>
						<tr><td class="font-500 text-center">Class</td><td class="hidden-xs"><?php echo $row[16];?></td></tr>
						<tr><td class="font-500 text-center">Percentage</td><td class="hidden-xs"><?php echo $row[17];?></td></tr>
						<tr><td class="font-500 text-center">Address</td><td class="hidden-xs"><?php echo $row[18];?></td></tr>
						
						<tr><td class="font-500 text-center">City</td><td class="hidden-xs"><?php echo $row[19];?></td></tr>
						<tr><td class="font-500 text-center">Pin Code</td><td class="hidden-xs"><?php echo $row[20];?></td></tr>
						<tr><td class="font-500 text-center">State</td><td class="hidden-xs"><?php echo $row[21];?></td></tr>
						<tr><td class="font-500 text-center">Country</td><td class="hidden-xs"><?php echo $row[22];?></td></tr>
						<tr><td class="font-500 text-center">Mobile Number </td><td class="hidden-xs"><?php echo $row[23];?></td></tr>
						<tr><td class="font-500 text-center">Alternate Mobile Number</td><td class="hidden-xs"><?php echo $row[24];?></td></tr>
						<tr><td class="font-500 text-center">Phone Number</td><td class="hidden-xs"><?php echo $row[25];?></td></tr>
						<tr><td class="font-500 text-center">Adhar Number</td><td class="hidden-xs"><?php echo $row[26];?></td></tr>
						<tr><td class="font-500 text-center">Total Number Of Family Members</td><td class="hidden-xs"><?php echo $row[28];?></td></tr>
						<tr><td class="font-500 text-center">Place</td><td class="hidden-xs"><?php echo $row[31];?></td></tr>
						<tr><td class="font-500 text-center">Date</td><td class="hidden-xs"><?php echo $row[32];?></td></tr>
						<?php
							$family_info = $row[27];
							//echo $family_info."<br>";
							$json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $family_info), true );
																
								$arr=array();
								foreach($json_array as $key => $arrays){
									//echo $key . "<br />";
									foreach($arrays as $array){
										foreach($array as $value)
										{
											
											array_push($arr,$value);
											//var_dump($value);
											
										}
									}
									echo "<br />";
								}
							//echo $arr[0];
							//exit();
							
							?>
						
							<tr><td class="font-500 text-center" colspan="2"></td></tr>
							<tr><td class="font-500 text-center" colspan="2"></td></tr>
							<tr><td class="font-500 text-center" colspan="2">Family Information</td></tr>
							<tr><td class="font-500 text-center" colspan="2"></td></tr>
							
							<tr><td class="font-500 text-center" colspan="2">Father's Information Information</td></tr>
						<tr><td class="font-500 text-center">Father Name</td><td class="hidden-xs"><?php echo $arr[0];?></td></tr>
						<tr><td class="font-500 text-center">Father Age</td><td class="hidden-xs"><?php echo $arr[1];?></td></tr>
						<tr><td class="font-500 text-center">Education</td><td class="hidden-xs"><?php echo $arr[2];?></td></tr>
						<tr><td class="font-500 text-center">Occupation</td><td class="hidden-xs"><?php echo $arr[3];?></td></tr>
						<tr><td class="font-500 text-center">Annual Income</td><td class="hidden-xs"><?php echo $arr[4];?></td></tr>
						<tr><td class="font-500 text-center">Email</td><td class="hidden-xs"><?php echo $arr[5];?></td></tr>
						<tr><td class="font-500 text-center">Office Address</td><td class="hidden-xs"><?php echo $arr[6];?></td></tr>
						<tr><td class="font-500 text-center">Mobile Number</td><td class="hidden-xs"><?php echo $arr[7];?></td></tr>
						<tr><td class="font-500 text-center">Father Signature</td><td class="hidden-xs"><img src="Student_Images/<?php echo $row[29]?>" height=70 width=70></td></tr>
						<tr><td class="font-500 text-center" colspan="2">Mother's Information Information</td></tr>
						<tr><td class="font-500 text-center">Mother Name</td><td class="hidden-xs"><?php echo $arr[8];?></td></tr>
						<tr><td class="font-500 text-center">Education Qualification</td><td class="hidden-xs"><?php echo $arr[9];?></td></tr>
						<tr><td class="font-500 text-center">Occupation</td><td class="hidden-xs"><?php echo $arr[10];?></td></tr>
						<tr><td class="font-500 text-center">Office Address</td><td class="hidden-xs"><?php echo $arr[11];?></td></tr>
						<tr><td class="font-500 text-center">Mobile Number</td><td class="hidden-xs"><?php echo $arr[12];?></td></tr>
						
						
						
						<tr><td class="font-500 text-center">Mother Signature</td><td class="hidden-xs"><img src="Student_Images/<?php echo $row[30]?>" height=70 width=70></td></tr>
						
						<tr><td class="font-500 text-center">Documents</td><td class="hidden-xs"><?php echo $row[33];?></td></tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
</div>
</div>
<div class="app-ui-mask-modal"></div>
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/core/jquery.slimscroll.min.js"></script>
<script src="assets/js/core/jquery.scrollLock.min.js"></script>
<script src="assets/js/core/jquery.placeholder.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/app-custom.js"></script>
<script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/js/pages/base_tables_datatables.js"></script>
</body>

</html>