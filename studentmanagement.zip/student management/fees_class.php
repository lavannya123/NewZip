<?php
$id=$_GET['id'];
//echo $id;
//echo"<script>alert('$id');</script>";
$con=mysqli_connect('localhost', 'root', '', 'school_management');
$total=0;

$sql2="SELECT * from fees_tbl inner join class_tbl as c on fees_tbl.class_id=c.id inner join student_info as s on fees_tbl.sid=s.id where fees_tbl.class_id=$id ";
	$rk=mysqli_query($con,$sql2);
	while($rl=mysqli_fetch_row($rk))
	{
	
			$sid=$rl[4];
			$cid=$rl[5];
		
		$sql="SELECT * FROM fees_tbl  INNER JOIN class_tbl ON fees_tbl.class_id = class_tbl.id INNER JOIN student_info ON fees_tbl.sid = student_info.id WHERE fees_tbl.sid='$sid' and fees_tbl.class_id='$cid'";
				
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_row($result))
					{
						
							$total=$total+$row[3];
					}	
					
		$m=$rl[2]-$total;
		echo $rl[0]."::".$rl[9]."::".$rl[16]." ".$rl[15]." ".$rl[17]."::".$rl[2]."::".$total."::".$m ."::".$rl[4]."::".$rl[5]."::"	;	
		

	}
	
?>
						
					