<?php
$id=$_GET["id"];
//echo $id;
$con=mysqli_connect('localhost', 'root', '', 'school_management');
$sql3="SELECT * FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where class_tbl.id='$id' GROUP BY fees_tbl.sid ";
$sql2="SELECT sum(paid_fees) FROM fees_tbl INNER JOIN student_info ON fees_tbl.sid = student_info.id INNER JOIN class_tbl ON fees_tbl.cid = class_tbl.id inner join admission_tbl on student_info.id=admission_tbl.sid where class_tbl.id='$id' GROUP BY fees_tbl.sid";
$rd=mysqli_query($con,$sql2);
$rd1=mysqli_query($con,$sql3);
$totalclass=0;
$paid_fees=0;
while($row1=mysqli_fetch_row($rd1))
{
    $rk=mysqli_fetch_row($rd);
    $totalclass+=$row1[47];
    $paid_fees+=$rk[0];
}
$remaning=$totalclass-$paid_fees;
echo $totalclass."::".$paid_fees."::".$remaning;
?>